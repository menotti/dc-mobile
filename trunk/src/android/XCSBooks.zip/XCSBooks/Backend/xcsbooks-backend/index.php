<?php
header("location: admin/");
?>